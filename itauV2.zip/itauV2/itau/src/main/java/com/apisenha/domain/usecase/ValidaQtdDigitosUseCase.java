package com.apisenha.domain.usecase;

public interface ValidaQtdDigitosUseCase {

    void validar(String senha);
}
