package com.apisenha.domain.usecase.impl;

import com.apisenha.domain.usecase.ValidaQtdDigitosUseCase;
import com.apisenha.exception.QtdDigitosInvalidosException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ValidaQtdDigitosUseCaseImpl implements ValidaQtdDigitosUseCase {

    private static final Pattern QTD_DIGITOS = Pattern.compile("\\d");

    @Override
    public void validar(String senha) {
        // Nesse trecho de código, está sendo implementado o S do SOLID (Single Responsibility Principle)
        // porque esta classe tem uma única responsabilidade: verificar se a senha contém ao menos um dígito.
        Matcher matcher = QTD_DIGITOS.matcher(senha);
        if (!matcher.find()) {
            throw new QtdDigitosInvalidosException();
        }
    }
}
