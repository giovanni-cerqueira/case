package com.apisenha.exception;

public class QtdDigitosInvalidosException extends ValidaSenhaException {
    public QtdDigitosInvalidosException() {
        super("ERRO002", "É necessário que a senha contenha ao menos 1 dígito.");
    }
}
