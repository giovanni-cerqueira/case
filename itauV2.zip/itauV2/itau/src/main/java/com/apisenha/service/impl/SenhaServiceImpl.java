package com.apisenha.service.impl;

import com.apisenha.domain.ValidaSenha;
import com.apisenha.service.SenhaService;
import org.springframework.stereotype.Service;

@Service
public class SenhaServiceImpl implements SenhaService {

    private final ValidaSenha validaSenha;

    // Nesse trecho de código, está sendo implementado o D do SOLID (Dependency Inversion Principle)
    // e a Inversão de Controle (IoC) do Spring Boot. O PasswordServiceImpl depende de uma abstração
    // (a interface PasswordValidator, mesmo que neste caso PasswordValidator seja uma classe concreta.
    // Em cenários mais complexos, PasswordValidator poderia ser uma interface com diferentes implementações).
    // Além disso, o Spring Boot está realizando a Inversão de Controle (IoC) ao injetar a dependência
    // de PasswordValidator no construtor.
    public SenhaServiceImpl(ValidaSenha validaSenha) {
        this.validaSenha = validaSenha;
    }

    @Override
    public boolean isSenhaValida(String senha) {
        // A lógica de validação real é delegada para a camada de domínio (PasswordValidator).
        // Isso mantém a camada de serviço focada na orquestração (que é simples neste caso).

        return validaSenha.isSenhaValida(senha);
        // Clean Architecture: A camada de serviço (ou um Interactor na camada de Use Cases)
        // orquestra a execução das regras de negócio definidas na camada de domínio.
    }
}
