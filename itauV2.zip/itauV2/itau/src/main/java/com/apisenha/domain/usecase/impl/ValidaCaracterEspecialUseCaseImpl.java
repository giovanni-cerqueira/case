package com.apisenha.domain.usecase.impl;

import com.apisenha.domain.usecase.ValidaCaracterEspecialUseCase;
import com.apisenha.exception.CaracterEspecialException;


public class ValidaCaracterEspecialUseCaseImpl implements ValidaCaracterEspecialUseCase {

    private static final String CARACTERES_ESPECIAIS = "!@#$%^&*()-+";

    @Override
    public void validar(String senha) {
        // Nesse trecho de código, está sendo implementado o S do SOLID (Single Responsibility Principle)
        // porque esta classe tem uma única responsabilidade: verificar se a senha contém ao menos um caractere especial.
        for (char c : senha.toCharArray()) {
            if (CARACTERES_ESPECIAIS.contains(String.valueOf(c))) {
                return;
            }
        }
        throw new CaracterEspecialException();
    }
}
