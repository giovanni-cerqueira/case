package com.apisenha.config;

import com.apisenha.domain.ValidaSenha;
import com.apisenha.domain.usecase.*;
import com.apisenha.domain.usecase.impl.*;
import com.apisenha.entrypoint.SenhaController;
import com.apisenha.service.SenhaService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public ValidaTamanhoSenhaUseCase validaTamanhoSenhaUseCase() {
        return new ValidaTamanhoSenhaUseCaseImpl();
    }

    @Bean
    public ValidaQtdDigitosUseCase validateDigitUseCase() {
        return new ValidaQtdDigitosUseCaseImpl();
    }

    @Bean
    public ValidaLetraMinusculaUseCase validaLetraMinusculaUseCase() {
        return new ValidaLetraMinusculaUseCaseImpl();
    }

    @Bean
    public ValidaLetraMaiusculaUseCase validaLetraMaiusculaUseCase() {
        return new ValidaLetraMaiusculaUseCaseImpl();
    }

    @Bean
    public ValidaCaracterEspecialUseCase validateSpecialCharUseCase() {
        return new ValidaCaracterEspecialUseCaseImpl();
    }

    @Bean
    public ValidaCaracterRepetidoUseCase validateNonRepeatingUseCase() {
        return new ValidaCaracterRepetidoUseCaseImpl();
    }

    @Bean
    public ValidaSenha validaSenha(ValidaTamanhoSenhaUseCase validaTamanhoSenhaUseCase,
                                   ValidaQtdDigitosUseCase validaQtdDigitosUseCase,
                                   ValidaLetraMinusculaUseCase validaLetraMinusculaUseCase,
                                   ValidaLetraMaiusculaUseCase validaLetraMaiusculaUseCase,
                                   ValidaCaracterEspecialUseCase validaCaracterEspecialUseCase,
                                   ValidaCaracterRepetidoUseCase validaCaracterRepetidoUseCase) {
        return new ValidaSenha(validaTamanhoSenhaUseCase, validaQtdDigitosUseCase, validaLetraMinusculaUseCase, validaLetraMaiusculaUseCase, validaCaracterEspecialUseCase, validaCaracterRepetidoUseCase);
    }

    @Bean
    public SenhaController senhaController(SenhaService validaSenha) {
        return new SenhaController(validaSenha);
    }
}