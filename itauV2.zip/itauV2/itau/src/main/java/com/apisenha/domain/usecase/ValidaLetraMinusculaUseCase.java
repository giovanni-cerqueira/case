package com.apisenha.domain.usecase;

public interface ValidaLetraMinusculaUseCase {

    void validar(String senha);
}
