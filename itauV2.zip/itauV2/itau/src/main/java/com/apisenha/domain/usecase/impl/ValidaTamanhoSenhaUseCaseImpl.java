package com.apisenha.domain.usecase.impl;

import com.apisenha.domain.usecase.ValidaTamanhoSenhaUseCase;
import com.apisenha.exception.TamanhoInvalidoException;


public class ValidaTamanhoSenhaUseCaseImpl implements ValidaTamanhoSenhaUseCase {

    @Override
    public void validar(String senha) {
        // Nesse trecho de código, está sendo implementado o S do SOLID (Single Responsibility Principle)
        // porque esta classe tem uma única responsabilidade: verificar se o comprimento da senha é válido.
        if (senha == null || senha.length() < 9) {
            throw new TamanhoInvalidoException();
        }
    }
}
