package com.apisenha.exception;

public class LetraMaiusculaException extends ValidaSenhaException {
    public LetraMaiusculaException() {
        super("ERRO004", "É necessário que a senha contenha ao menos 1 letra maiúscula.");
    }
}