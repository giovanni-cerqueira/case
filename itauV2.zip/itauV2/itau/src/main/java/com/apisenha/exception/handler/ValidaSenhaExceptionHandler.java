package com.apisenha.exception.handler;

import com.apisenha.exception.SenhaErrorCodeEnum;
import com.apisenha.exception.ValidaSenhaException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class ValidaSenhaExceptionHandler  {

    @ExceptionHandler(ValidaSenhaException.class)
    public ResponseEntity<Map<String, String>> validaSenhaException(ValidaSenhaException ex) {
        Map<String, String> errorResponse = new HashMap<>();
//        SenhaErrorCodeEnum errorCode = ex.getErrorCode();
        errorResponse.put("codigo", ex.getCodigo());
        errorResponse.put("mensagem", ex.getMensagem());
        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> argumentNotValidException(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
    }

    // Você pode adicionar outros métodos @ExceptionHandler aqui para tratar
    // outras exceptions específicas, se necessário. Por exemplo, se você tiver
    // um caso de erro de entrada diferente que não se encaixa nas suas
    // PasswordValidationException, você poderia tratá-lo aqui com um status 400
    // e um formato de resposta diferente, se desejado.

    // Exceptions não tratadas explicitamente aqui (como outras RuntimeExceptions)
    // ainda serão tratadas pelo tratamento padrão do Spring Boot (geralmente status 500).
}
