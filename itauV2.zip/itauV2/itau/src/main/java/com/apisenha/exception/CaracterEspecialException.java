package com.apisenha.exception;

public class CaracterEspecialException extends ValidaSenhaException {

    private final SenhaErrorCodeEnum errorCode = SenhaErrorCodeEnum.AUSENCIA_ESPECIAL;

    public CaracterEspecialException() {
        super(SenhaErrorCodeEnum.AUSENCIA_ESPECIAL.getCodigo(), SenhaErrorCodeEnum.AUSENCIA_ESPECIAL.getMensagem());
    }

    public SenhaErrorCodeEnum getErrorCode() {
        return errorCode;
    }
}
