package com.apisenha.exception;

public class LetraMinusculaException extends ValidaSenhaException {
    public LetraMinusculaException() {
        super("ERRO003", "É necessário que a senha contenha ao menos 1 letra minúscula.");
    }
}
