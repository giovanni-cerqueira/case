package com.apisenha.entrypoint;

import com.apisenha.domain.model.SenhaDTO;
import com.apisenha.service.SenhaService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/senha")
public class SenhaController {

    private final SenhaService senhaService;

    public SenhaController(SenhaService senhaService) {
        this.senhaService = senhaService;
    }

    @PostMapping("/validar")
    public ResponseEntity<Map<String, Boolean>> validaSenha(@RequestBody @Valid SenhaDTO senhaDTO) {
        String senha = senhaDTO.senha();
        boolean ehValida = senhaService.isSenhaValida(senha);
        return ResponseEntity.ok(Map.of("senhaValida", ehValida));
    }
}
