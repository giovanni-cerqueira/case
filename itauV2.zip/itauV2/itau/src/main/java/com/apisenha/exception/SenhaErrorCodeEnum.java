package com.apisenha.exception;

public enum SenhaErrorCodeEnum {

    TAMANHO_INSUFICIENTE("ERRO001", "É necessário que a senha tenha nove ou mais caracteres."),
    AUSENCIA_DIGITO("ERRO002", "É necessário que a senha contenha ao menos 1 dígito."),
    AUSENCIA_MINUSCULA("ERRO003", "É necessário que a senha contenha ao menos 1 letra minúscula."),
    AUSENCIA_MAIUSCULA("ERRO004", "É necessário que a senha contenha ao menos 1 letra maiúscula."),
    AUSENCIA_ESPECIAL("ERRO005", "É necessário que a senha contenha ao menos 1 caractere especial (!@#$%^&*()-+)."),
    CARACTER_REPETIDO("ERRO006", "A senha não pode ter caracteres repetidos sequencialmente.");

    private final String codigo;
    private final String mensagem;

    SenhaErrorCodeEnum(String codigo, String mensagem) {
        this.codigo = codigo;
        this.mensagem = mensagem;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getMensagem() {
        return mensagem;
    }
}
