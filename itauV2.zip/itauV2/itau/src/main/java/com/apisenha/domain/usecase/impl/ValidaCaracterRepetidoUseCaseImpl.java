package com.apisenha.domain.usecase.impl;

import com.apisenha.domain.usecase.ValidaCaracterRepetidoUseCase;
import com.apisenha.exception.CaracterRepetidoException;

import java.util.HashSet;
import java.util.Set;


public class ValidaCaracterRepetidoUseCaseImpl implements ValidaCaracterRepetidoUseCase {

    @Override
    public void validar(String senha) {
        // Nesse trecho de código, está sendo implementado o S do SOLID (Single Responsibility Principle)
        // porque esta classe tem uma única responsabilidade: verificar se a senha não possui caracteres repetidos.
        Set<Character> uniqueChars = new HashSet<>();
        for (char c : senha.toCharArray()) {
            if (!uniqueChars.add(c)) {
                throw new CaracterRepetidoException();
            }
        }
    }
}
