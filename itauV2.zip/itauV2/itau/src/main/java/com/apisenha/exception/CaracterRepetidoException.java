package com.apisenha.exception;

public class CaracterRepetidoException extends ValidaSenhaException {
    public CaracterRepetidoException() {
        super("ERRO006", "A senha não pode possuir caracteres repetidos dentro do conjunto.");
    }
}
