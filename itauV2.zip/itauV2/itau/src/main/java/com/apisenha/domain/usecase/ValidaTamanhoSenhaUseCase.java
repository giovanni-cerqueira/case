package com.apisenha.domain.usecase;

public interface ValidaTamanhoSenhaUseCase {

    void validar(String senha);
}
