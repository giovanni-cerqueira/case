package com.apisenha.exception;

public class TamanhoInvalidoException extends ValidaSenhaException {
    public TamanhoInvalidoException() {
        super("ERRO001", "É necessário que a senha tenha nove ou mais caracteres.");
    }
}
