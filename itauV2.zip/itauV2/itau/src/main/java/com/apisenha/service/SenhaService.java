package com.apisenha.service;

public interface SenhaService {
    boolean isSenhaValida(String password);
}