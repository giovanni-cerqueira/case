package com.apisenha.domain.usecase;

public interface ValidaCaracterRepetidoUseCase {

    void validar(String senha);
}
