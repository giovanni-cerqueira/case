package com.apisenha.domain.model;

import jakarta.validation.constraints.NotNull;

public record SenhaDTO(
        @NotNull(message = "O campo 'senha' é obrigatório")
        String senha) {
}
