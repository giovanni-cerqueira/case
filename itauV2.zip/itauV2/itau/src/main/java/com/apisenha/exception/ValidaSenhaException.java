package com.apisenha.exception;

public class ValidaSenhaException extends RuntimeException {
    private final String codigo;
    private final String mensagem;

    public ValidaSenhaException(String codigo, String mensagem) {
        this.codigo = codigo;
        this.mensagem = mensagem;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getMensagem() {
        return mensagem;
    }
}
