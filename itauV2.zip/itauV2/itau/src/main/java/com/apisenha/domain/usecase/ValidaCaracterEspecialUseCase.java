package com.apisenha.domain.usecase;

public interface ValidaCaracterEspecialUseCase {

    void validar(String senha);
}
