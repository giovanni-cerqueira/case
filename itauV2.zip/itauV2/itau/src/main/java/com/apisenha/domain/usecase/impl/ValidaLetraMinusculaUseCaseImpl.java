package com.apisenha.domain.usecase.impl;

import com.apisenha.domain.usecase.ValidaLetraMinusculaUseCase;
import com.apisenha.exception.LetraMinusculaException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ValidaLetraMinusculaUseCaseImpl implements ValidaLetraMinusculaUseCase {

    private static final Pattern PATTERN_MINUSCULAS = Pattern.compile("[a-z]");

    @Override
    public void validar(String senha) {
        // Nesse trecho de código, está sendo implementado o S do SOLID (Single Responsibility Principle)
        // porque esta classe tem uma única responsabilidade: verificar se a senha contém ao menos uma letra minúscula.
        Matcher matcher = PATTERN_MINUSCULAS.matcher(senha);
        if (!matcher.find()) {
            throw new LetraMinusculaException();
        }
    }
}
