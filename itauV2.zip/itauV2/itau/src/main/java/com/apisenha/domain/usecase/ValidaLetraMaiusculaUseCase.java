package com.apisenha.domain.usecase;

public interface ValidaLetraMaiusculaUseCase {

    void validar(String senha);
}
