package com.apisenha.domain;

import com.apisenha.domain.usecase.*;


public class ValidaSenha {

    private final ValidaTamanhoSenhaUseCase validaTamanhoSenhaUseCase;
    private final ValidaQtdDigitosUseCase validaQtdDigitosUseCase;
    private final ValidaLetraMinusculaUseCase validaLetraMinusculaUseCase;
    private final ValidaLetraMaiusculaUseCase validaLetraMaiusculaUseCase;
    private final ValidaCaracterEspecialUseCase validaCaracterEspecialUseCase;
    private final ValidaCaracterRepetidoUseCase validaCaracterRepetidoUseCase;

    // Injeção de Dependências (DIP) do SOLID e Inversão de Dependência:
    // Dependemos das abstrações (interfaces) dos casos de uso.
    public ValidaSenha(ValidaTamanhoSenhaUseCase validaTamanhoSenhaUseCase,
                       ValidaQtdDigitosUseCase validaQtdDigitosUseCase,
                       ValidaLetraMinusculaUseCase validaLetraMinusculaUseCase,
                       ValidaLetraMaiusculaUseCase validaLetraMaiusculaUseCase,
                       ValidaCaracterEspecialUseCase validaCaracterEspecialUseCase,
                       ValidaCaracterRepetidoUseCase validaCaracterRepetidoUseCase) {
        this.validaTamanhoSenhaUseCase = validaTamanhoSenhaUseCase;
        this.validaQtdDigitosUseCase = validaQtdDigitosUseCase;
        this.validaLetraMinusculaUseCase = validaLetraMinusculaUseCase;
        this.validaLetraMaiusculaUseCase = validaLetraMaiusculaUseCase;
        this.validaCaracterEspecialUseCase = validaCaracterEspecialUseCase;
        this.validaCaracterRepetidoUseCase = validaCaracterRepetidoUseCase;
    }

    public boolean isSenhaValida(String senha) {
        // Nesse trecho de código, estamos implementando o Princípio da Inversão de Dependências (DIP) do SOLID
        // ao depender de abstrações (interfaces dos use cases) em vez de implementações concretas.
        validaTamanhoSenhaUseCase.validar(senha);
        validaQtdDigitosUseCase.validar(senha);
        validaLetraMinusculaUseCase.validar(senha);
        validaLetraMaiusculaUseCase.validar(senha);
        validaCaracterEspecialUseCase.validar(senha);
        validaCaracterRepetidoUseCase.validar(senha);
        return true;
    }
}