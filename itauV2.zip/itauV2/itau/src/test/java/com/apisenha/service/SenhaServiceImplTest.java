package com.apisenha.service;

public class SenhaServiceImplTest {
}
