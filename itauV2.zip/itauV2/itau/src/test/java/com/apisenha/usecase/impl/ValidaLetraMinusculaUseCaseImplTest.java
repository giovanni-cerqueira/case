package com.apisenha.usecase.impl;

import com.apisenha.domain.usecase.ValidaLetraMinusculaUseCase;
import com.apisenha.domain.usecase.impl.ValidaLetraMinusculaUseCaseImpl;
import com.apisenha.exception.LetraMinusculaException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class ValidaLetraMinusculaUseCaseImplTest {

    // Cria uma instância da classe a ser testada
    private final ValidaLetraMinusculaUseCaseImpl validaLetraMinusculaUseCase = new ValidaLetraMinusculaUseCaseImpl();

    @Test
    void dadaUmaSenhaComAoMenosUmaLetraMinuscula_quandoValidar_entaoNenhumaExcecaoEhLancada() {
        // Cenário: Uma senha contendo pelo menos uma letra minúscula é fornecida.
        String senhaComMinuscula = "Senha1a!";
        String senhaComVariasMinusculas = "sEnHaFOrTe!";

        // Ação: Chama o método validar para as senhas válidas.
        // Asserção: Verifica se nenhuma exceção (LetraMinusculaException) é lançada.
        assertDoesNotThrow(() -> validaLetraMinusculaUseCase.validar(senhaComMinuscula));
        assertDoesNotThrow(() -> validaLetraMinusculaUseCase.validar(senhaComVariasMinusculas));
    }

    @Test
    void dadaUmaSenhaSemLetrasMinusculas_quandoValidar_entaoLetraMinusculaExceptionEhLancada() {
        // Cenário: Uma senha que não contém nenhuma letra minúscula é fornecida.
        String senhaSemMinuscula = "SENHA123!";

        // Ação: Chama o método validar para a senha inválida.
        // Asserção: Verifica se uma LetraMinusculaException é lançada.
        assertThrows(LetraMinusculaException.class, () -> validaLetraMinusculaUseCase.validar(senhaSemMinuscula));
    }

    @Test
    void dadaUmaSenhaNula_quandoValidar_entaoLetraMinusculaExceptionEhLancada() {
        // Cenário: Uma senha nula é fornecida.
        String senhaNula = null;

        // Ação: Chama o método validar para a senha nula.
        // Asserção: Verifica se uma LetraMinusculaException é lançada (o regex pode se comportar de forma inesperada com null).
        assertThrows(LetraMinusculaException.class, () -> validaLetraMinusculaUseCase.validar(senhaNula));
    }
}
