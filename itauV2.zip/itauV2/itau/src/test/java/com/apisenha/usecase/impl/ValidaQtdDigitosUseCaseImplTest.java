package com.apisenha.usecase.impl;

import com.apisenha.domain.usecase.impl.ValidaQtdDigitosUseCaseImpl;
import com.apisenha.exception.QtdDigitosInvalidosException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class ValidaQtdDigitosUseCaseImplTest {

    // Cria uma instância da classe a ser testada
    private final ValidaQtdDigitosUseCaseImpl validaQtdDigitosUseCase = new ValidaQtdDigitosUseCaseImpl();

    @Test
    void dadaUmaSenhaComAoMenosUmDigito_quandoValidar_entaoNenhumaExcecaoEhLancada() {
        // Cenário: Uma senha contendo pelo menos um dígito é fornecida.
        String senhaComDigito = "Senha1!";
        String senhaComVariosDigitos = "S3nh4F0rt3!";

        // Ação: Chama o método validar para as senhas válidas.
        // Asserção: Verifica se nenhuma exceção (QtdDigitosInvalidosException) é lançada.
        assertDoesNotThrow(() -> validaQtdDigitosUseCase.validar(senhaComDigito));
        assertDoesNotThrow(() -> validaQtdDigitosUseCase.validar(senhaComVariosDigitos));
    }

    @Test
    void dadaUmaSenhaSemDigitos_quandoValidar_entaoQtdDigitosInvalidosExceptionEhLancada() {
        // Cenário: Uma senha que não contém nenhum dígito é fornecida.
        String senhaSemDigito = "SenhaForte!";

        // Ação: Chama o método validar para a senha inválida.
        // Asserção: Verifica se uma QtdDigitosInvalidosException é lançada.
        assertThrows(QtdDigitosInvalidosException.class, () -> validaQtdDigitosUseCase.validar(senhaSemDigito));
    }

    @Test
    void dadaUmaSenhaNula_quandoValidar_entaoQtdDigitosInvalidosExceptionEhLancada() {
        // Cenário: Uma senha nula é fornecida.
        String senhaNula = null;

        // Ação: Chama o método validar para a senha nula.
        // Asserção: Verifica se uma QtdDigitosInvalidosException é lançada (o regex pode se comportar de forma inesperada com null).
        assertThrows(QtdDigitosInvalidosException.class, () -> validaQtdDigitosUseCase.validar(senhaNula));
    }
}
