package com.apisenha.usecase.impl;

import com.apisenha.domain.usecase.impl.ValidaCaracterRepetidoUseCaseImpl;
import com.apisenha.exception.CaracterRepetidoException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class ValidaCaracterRepetidoUseCaseImplTest {

    // Cria uma instância da classe a ser testada
    private final ValidaCaracterRepetidoUseCaseImpl validaCaracterRepetidoUseCase = new ValidaCaracterRepetidoUseCaseImpl();

    @Test
    void dadaUmaSenhaSemCaracteresRepetidos_quandoValidar_entaoNenhumaExcecaoEhLancada() {
        // Cenário: Uma senha sem caracteres repetidos é fornecida.
        String senhaUnica = "Senha1a!";
        String senhaUnicaComSimbolos = "!@#1aB$";

        // Ação: Chama o método validar para as senhas válidas.
        // Asserção: Verifica se nenhuma exceção (CaracterRepetidoException) é lançada.
        assertDoesNotThrow(() -> validaCaracterRepetidoUseCase.validar(senhaUnica));
        assertDoesNotThrow(() -> validaCaracterRepetidoUseCase.validar(senhaUnicaComSimbolos));
    }

    @Test
    void dadaUmaSenhaComCaracteresRepetidos_quandoValidar_entaoCaracterRepetidoExceptionEhLancada() {
        // Cenário: Uma senha contendo caracteres repetidos é fornecida.
        String senhaComRepeticao = "Senhaaa1!";
        String senhaComRepeticaoNoInicio = "SSenha1!";
        String senhaComRepeticaoNoFinal = "Senha1!!";

        // Ação: Chama o método validar para as senhas inválidas.
        // Asserção: Verifica se uma CaracterRepetidoException é lançada.
        assertThrows(CaracterRepetidoException.class, () -> validaCaracterRepetidoUseCase.validar(senhaComRepeticao));
        assertThrows(CaracterRepetidoException.class, () -> validaCaracterRepetidoUseCase.validar(senhaComRepeticaoNoInicio));
        assertThrows(CaracterRepetidoException.class, () -> validaCaracterRepetidoUseCase.validar(senhaComRepeticaoNoFinal));
    }

    @Test
    void dadaUmaSenhaNula_quandoValidar_entaoNenhumaExcecaoEhLancada() {
        // Cenário: Uma senha nula é fornecida.
        String senhaNula = null;

        // Ação: Chama o método validar para a senha nula.
        // Asserção: Verifica se nenhuma CaracterRepetidoException é lançada (a iteração sobre char[] com null não causa erro aqui).
        assertDoesNotThrow(() -> validaCaracterRepetidoUseCase.validar(senhaNula));
    }
}
