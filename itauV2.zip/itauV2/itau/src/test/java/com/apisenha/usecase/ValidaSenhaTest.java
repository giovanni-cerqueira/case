package com.apisenha.usecase;

import com.apisenha.domain.ValidaSenha;
import com.apisenha.domain.usecase.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class ValidaSenhaTest {

    @InjectMocks // Injecta as instâncias mocks dos use cases em ValidaSenha
    private ValidaSenha validaSenha;

    @Mock // Cria mocks para cada dependência de use case
    private ValidaTamanhoSenhaUseCase validaTamanhoSenhaUseCase;
    @Mock
    private ValidaQtdDigitosUseCase validaQtdDigitosUseCase;
    @Mock
    private ValidaLetraMinusculaUseCase validaLetraMinusculaUseCase;
    @Mock
    private ValidaLetraMaiusculaUseCase validaLetraMaiusculaUseCase;
    @Mock
    private ValidaCaracterEspecialUseCase validaCaracterEspecialUseCase;
    @Mock
    private ValidaCaracterRepetidoUseCase validaCaracterRepetidoUseCase;

    @Test
    void dadaUmaSenha_quandoIsSenhaValida_entaoTodosOsValidadoresSaoChamados() {
        // Cenário: Uma senha qualquer é fornecida para validação.
        String senha = "Senha123!";

        // Ação: Chama o método isSenhaValida do ValidaSenha.
        boolean resultado = validaSenha.isSenhaValida(senha);

        // Asserções: Verifica se o método 'validar' de cada um dos use cases foi chamado exatamente uma vez.
        verify(validaTamanhoSenhaUseCase, times(1)).validar(senha);
        verify(validaQtdDigitosUseCase, times(1)).validar(senha);
        verify(validaLetraMinusculaUseCase, times(1)).validar(senha);
        verify(validaLetraMaiusculaUseCase, times(1)).validar(senha);
        verify(validaCaracterEspecialUseCase, times(1)).validar(senha);
        verify(validaCaracterRepetidoUseCase, times(1)).validar(senha);

        // Asserção adicional: Verifica se o resultado retornado é verdadeiro (já que nenhuma exception foi lançada pelos mocks).
        assertTrue(resultado);
    }
}
