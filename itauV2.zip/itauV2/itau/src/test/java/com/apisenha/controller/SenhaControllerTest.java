package com.apisenha.controller;

public class SenhaControllerTest {
}
