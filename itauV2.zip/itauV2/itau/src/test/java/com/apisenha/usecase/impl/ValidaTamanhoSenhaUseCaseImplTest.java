package com.apisenha.usecase.impl;

import com.apisenha.domain.usecase.impl.ValidaTamanhoSenhaUseCaseImpl;
import com.apisenha.exception.TamanhoInvalidoException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class ValidaTamanhoSenhaUseCaseImplTest {

    // Cria uma instância da classe a ser testada
    private final ValidaTamanhoSenhaUseCaseImpl validaTamanhoSenhaUseCase = new ValidaTamanhoSenhaUseCaseImpl();

    @Test
    void dadaUmaSenhaComNoveCaracteresOuMais_quandoValidar_entaoNenhumaExcecaoEhLancada() {
        // Cenário: Uma senha com o comprimento mínimo válido (9 caracteres) é fornecida.
        String senhaValidaMinima = "Senha1234";
        String senhaValidaMaior = "SenhaForte1!";

        // Ação: Chama o método validar para a senha válida mínima e uma senha maior.
        // Asserção: Verifica se nenhuma exceção (TamanhoInvalidoException) é lançada.
        assertDoesNotThrow(() -> validaTamanhoSenhaUseCase.validar(senhaValidaMinima));
        assertDoesNotThrow(() -> validaTamanhoSenhaUseCase.validar(senhaValidaMaior));
    }

    @Test
    void dadaUmaSenhaComMenosDeNoveCaracteres_quandoValidar_entaoTamanhoInvalidoExceptionEhLancada() {
        // Cenário: Uma senha com comprimento inferior ao mínimo válido (9 caracteres) é fornecida.
        String senhaInvalida = "Senha123";

        // Ação: Chama o método validar para a senha inválida.
        // Asserção: Verifica se uma TamanhoInvalidoException é lançada.
        assertThrows(TamanhoInvalidoException.class, () -> validaTamanhoSenhaUseCase.validar(senhaInvalida));
    }

    @Test
    void dadaUmaSenhaNula_quandoValidar_entaoTamanhoInvalidoExceptionEhLancada() {
        // Cenário: Uma senha nula é fornecida.
        String senhaNula = null;

        // Ação: Chama o método validar para a senha nula.
        // Asserção: Verifica se uma TamanhoInvalidoException é lançada.
        assertThrows(TamanhoInvalidoException.class, () -> validaTamanhoSenhaUseCase.validar(senhaNula));
    }
}
