package com.apisenha.usecase.impl;

import com.apisenha.domain.usecase.impl.ValidaCaracterEspecialUseCaseImpl;
import com.apisenha.exception.CaracterEspecialException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class ValidaCaracterEspecialUseCaseImplTest {

    // Cria uma instância da classe a ser testada
    private final ValidaCaracterEspecialUseCaseImpl validaCaracterEspecialUseCase = new ValidaCaracterEspecialUseCaseImpl();

    @Test
    void dadaUmaSenhaComAoMenosUmCaracterEspecial_quandoValidar_entaoNenhumaExcecaoEhLancada() {
        // Cenário: Uma senha contendo pelo menos um caractere especial é fornecida.
        String senhaComEspecial = "Senha1a!";
        String senhaComVariosEspeciais = "!S@n#a$";

        // Ação: Chama o método validar para as senhas válidas.
        // Asserção: Verifica se nenhuma exceção (CaracterEspecialException) é lançada.
        assertDoesNotThrow(() -> validaCaracterEspecialUseCase.validar(senhaComEspecial));
        assertDoesNotThrow(() -> validaCaracterEspecialUseCase.validar(senhaComVariosEspeciais));
    }

    @Test
    void dadaUmaSenhaSemCaracteresEspeciais_quandoValidar_entaoCaracterEspecialExceptionEhLancada() {
        // Cenário: Uma senha que não contém nenhum caractere especial é fornecida.
        String senhaSemEspecial = "Senha123a";

        // Ação: Chama o método validar para a senha inválida.
        // Asserção: Verifica se uma CaracterEspecialException é lançada.
        assertThrows(CaracterEspecialException.class, () -> validaCaracterEspecialUseCase.validar(senhaSemEspecial));
    }

    @Test
    void dadaUmaSenhaNula_quandoValidar_entaoCaracterEspecialExceptionEhLancada() {
        // Cenário: Uma senha nula é fornecida.
        String senhaNula = null;

        // Ação: Chama o método validar para a senha nula.
        // Asserção: Verifica se uma CaracterEspecialException é lançada (a iteração sobre char[] pode lançar NullPointerException).
        assertThrows(NullPointerException.class, () -> validaCaracterEspecialUseCase.validar(senhaNula));
    }
}
