package com.apisenha;

import com.apisenha.controller.SenhaControllerTest;
import com.apisenha.service.SenhaServiceImplTest;
import com.apisenha.usecase.ValidaSenhaTest;
import com.apisenha.usecase.impl.*;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.SuiteDisplayName;
import org.junit.platform.suite.api.SelectClasses;

@Suite
@SuiteDisplayName("Conjunto de Testes Unitários da API de Senhas")
@SelectClasses({
        SenhaControllerTest.class,
        SenhaServiceImplTest.class,
        ValidaSenhaTest.class,
        ValidaTamanhoSenhaUseCaseImplTest.class,
        ValidaQtdDigitosUseCaseImplTest.class,
        ValidaLetraMinusculaUseCaseImplTest.class,
        ValidaLetraMaiusculaUseCaseImplTest.class,
        ValidaCaracterEspecialUseCaseImplTest.class,
        ValidaCaracterRepetidoUseCaseImplTest.class
})
public class ExecutaTodosTestesUnitarios {
}
