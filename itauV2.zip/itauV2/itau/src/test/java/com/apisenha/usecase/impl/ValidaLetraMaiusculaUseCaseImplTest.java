package com.apisenha.usecase.impl;

import com.apisenha.domain.usecase.ValidaLetraMaiusculaUseCase;
import com.apisenha.domain.usecase.impl.ValidaLetraMaiusculaUseCaseImpl;
import com.apisenha.exception.LetraMaiusculaException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
public class ValidaLetraMaiusculaUseCaseImplTest {

    // Cria uma instância da classe a ser testada
    private final ValidaLetraMaiusculaUseCaseImpl validaLetraMaiusculaUseCase = new ValidaLetraMaiusculaUseCaseImpl();

    @Test
    void dadaUmaSenhaComAoMenosUmaLetraMaiuscula_quandoValidar_entaoNenhumaExcecaoEhLancada() {
        // Cenário: Uma senha contendo pelo menos uma letra maiúscula é fornecida.
        String senhaComMaiuscula = "Senha1a!";
        String senhaComVariasMaiusculas = "sEnHaFOrTe!";

        // Ação: Chama o método validar para as senhas válidas.
        // Asserção: Verifica se nenhuma exceção (LetraMaiusculaException) é lançada.
        assertDoesNotThrow(() -> validaLetraMaiusculaUseCase.validar(senhaComMaiuscula));
        assertDoesNotThrow(() -> validaLetraMaiusculaUseCase.validar(senhaComVariasMaiusculas));
    }

    @Test
    void dadaUmaSenhaSemLetrasMaiusculas_quandoValidar_entaoLetraMaiusculaExceptionEhLancada() {
        // Cenário: Uma senha que não contém nenhuma letra maiúscula é fornecida.
        String senhaSemMaiuscula = "senha123!";

        // Ação: Chama o método validar para a senha inválida.
        // Asserção: Verifica se uma LetraMaiusculaException é lançada.
        assertThrows(LetraMaiusculaException.class, () -> validaLetraMaiusculaUseCase.validar(senhaSemMaiuscula));
    }

    @Test
    void dadaUmaSenhaNula_quandoValidar_entaoLetraMaiusculaExceptionEhLancada() {
        // Cenário: Uma senha nula é fornecida.
        String senhaNula = null;

        // Ação: Chama o método validar para a senha nula.
        // Asserção: Verifica se uma LetraMaiusculaException é lançada (o regex pode se comportar de forma inesperada com null).
        assertThrows(LetraMaiusculaException.class, () -> validaLetraMaiusculaUseCase.validar(senhaNula));
    }
}
